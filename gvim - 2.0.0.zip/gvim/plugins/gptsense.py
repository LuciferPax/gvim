import tkinter as tk
from openai import OpenAI
import threading

def run(api):
    """Plugin that adds GPT-powered auto-completion to the text editor with a 3-second delay,
    showing suggestions in a lighter shade, and confirming with Tab."""
    
    api_key = "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"
    client = OpenAI(api_key=api_key)
    
    delay_time = 2000  # 3 seconds delay
    api.suggest_after_id = None
    api.current_suggestion = None
    api.suggestion_start_index = None
    api.prompt_window = None

    # Function to request GPT auto-completion
    def request_completion(prompt):
        try:
            completion = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "Continue the code, use no markdown"},
                    {"role": "user", "content": f"{prompt}"},
                ]
            )
            return completion.choices[0].message.content.strip()
        except Exception as e:
            print(f"Error fetching suggestion: {e}")
            return ""
        
    def contextual_prompt(prompt, ctx):
        try:
            completion = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": f"Generate code based on the context, use no markdown\ncontext:\n{ctx}"},
                    {"role": "user", "content": f"{prompt}"},
                ]
            )
            return completion.choices[0].message.content.strip()
        except Exception as e:
            print(f"Error fetching suggestion: {e}")
            return ""
        
    def get_codebase_context():
        """Fetch the entire codebase as context."""
        return api.get_text()

    def suggest_completion():
        if not hasattr(api, 'is_suggesting'):
            api.is_suggesting = False

        if api.is_suggesting:
            return
        
        api.is_suggesting = True

        cursor_position = api.get_cursor_position()
        current_text = api.get_text()
        current_line = current_text.splitlines()[int(cursor_position.split('.')[0]) - 1]

        # Start a new thread to avoid blocking the UI
        threading.Thread(target=fetch_and_show_completion, args=(current_line, cursor_position)).start()

    def fetch_and_show_completion(current_line, cursor_position):
        suggestion = request_completion(current_line)

        if suggestion:
            # Show the suggestion in a lighter shade
            api.current_suggestion = suggestion
            api.suggestion_start_index = cursor_position
            end_index = f"{cursor_position}+{len(suggestion)}c"
            api.editor.text_area.insert(cursor_position, suggestion)
            api.editor.text_area.tag_add("suggestion", cursor_position, end_index)
            api.editor.text_area.tag_config("suggestion", foreground="gray", underline=True)
            api.set_cursor_position(cursor_position)

        api.is_suggesting = False

    def schedule_suggestion(event=None):
        """Schedule the suggestion after a delay."""
        ignored_keys = [
        'Caps_Lock', 'Control_L', 'Control_R', 'Alt_L', 'Alt_R', 'Win_L', 'Win_R',
        'Delete', 'BackSpace', 'Shift_L', 'Shift_R', 'Escape', 'F1', 'F2', 'F3', 
        'F4', 'F5', 'F6', 'F7', 'F8', 'F9', 'F10', 'F11', 'F12', 'Tab', 'Return'
        ]

        if event.keysym in ignored_keys:
            return  # Do not schedule suggestion on space or enter

        if api.suggest_after_id:
            api.editor.root.after_cancel(api.suggest_after_id)
        api.suggest_after_id = api.editor.root.after(delay_time, suggest_completion)

    def confirm_suggestion(event=None):
        """Replace the lighter text with normal text when Tab is pressed."""
        if api.current_suggestion and api.suggestion_start_index:
            start = api.suggestion_start_index
            end = f"{start}+{len(api.current_suggestion)}c"
            api.editor.text_area.tag_remove("suggestion", start, end)
            api.editor.text_area.tag_add("normal", start, end)
            api.editor.text_area.tag_config("normal", foreground=api.editor.current_scheme["foreground_color"])
            api.current_suggestion = None
            api.suggestion_start_index = None
            return "break"  # Prevent default Tab behavior

    def cancel_suggestion(event=None):
        """Remove the suggestion if the user continues typing."""
        if api.current_suggestion and api.suggestion_start_index:
            start = api.suggestion_start_index
            end = f"{start}+{len(api.current_suggestion)}c"
            api.editor.text_area.delete(start, end)
            api.current_suggestion = None
            api.suggestion_start_index = None

    def shift_color(color, shift):
        color = color.lstrip("#")
        rgb = tuple(int(color[i:i+2], 16) for i in (0, 2, 4))
        new_rgb = tuple(max(0, min(255, c + shift)) for c in rgb)
        return f"#{new_rgb[0]:02x}{new_rgb[1]:02x}{new_rgb[2]:02x}"
    
    def open_prompt_menu(event=None):
        """Open a small input window for generating ideas."""
        if api.prompt_window:
            return
    
        # Get the current cursor position in the text area
        cursor_position = api.editor.text_area.index(tk.INSERT)
        x, y, _, _ = api.editor.text_area.bbox(cursor_position)
    
        # Convert text area coordinates to root window coordinates
        text_area_x = api.editor.text_area.winfo_rootx()
        text_area_y = api.editor.text_area.winfo_rooty()
    
        # Calculate the final position for the prompt window (above the cursor)
        window_x = text_area_x + x
        window_y = text_area_y + y - 50  # Adjust the offset to place the window above
    
        # Create the prompt window
        api.prompt_window = tk.Toplevel(api.editor.root)
        api.prompt_window.title("Generate Code Idea")
        api.prompt_window.geometry(f"400x100+{window_x}+{window_y}")
        api.prompt_window.config(bg=shift_color(api.editor.current_scheme["background_color"], 15))
        api.prompt_window.overrideredirect(True)  # Remove window decorations
    
        # Make the window draggable
        api.prompt_window.bind("<ButtonPress-1>", start_move)
        api.prompt_window.bind("<B1-Motion>", do_move)
    
        # Input field inside the prompt window
        api.input_var = tk.StringVar()
        input_field = tk.Entry(api.prompt_window, textvariable=api.input_var, 
                               bg=shift_color(api.editor.current_scheme["background_color"], 25),
                               fg=api.editor.current_scheme["foreground_color"],
                               insertbackground=api.editor.current_scheme["insertbackground_color"],
                               relief="flat", font=api.editor.text_font)
        input_field.place(x=20, y=30, width=360, height=30)
    
        input_field.bind("<Return>", generate_idea)
        input_field.bind("<Escape>", close_prompt_window)
        input_field.focus_set()
    

    def generate_idea(event=None):
        """Generate code based on input text and context."""
        if not api.prompt_window:
            return

        input_text = api.input_var.get().strip()
        if input_text:
            context = get_codebase_context()
            suggestion = contextual_prompt(input_text, context)
            if suggestion:
                start = api.get_cursor_position()
                end = f"{start}+{len(suggestion)}c"
                api.editor.text_area.insert(start, suggestion)
                api.editor.text_area.tag_add("suggestion", start, end)
                api.editor.text_area.tag_config("suggestion", foreground="gray", underline=True)
                api.set_cursor_position(start)
                api.current_suggestion = suggestion  # Set the suggestion for confirmation/cancelation
                api.suggestion_start_index = start
        close_prompt_window()

    def close_prompt_window(event=None):
        """Close the prompt window."""
        if api.prompt_window:
            api.prompt_window.destroy()
            api.prompt_window = None

    def start_move(event):
        api.prompt_window.x = event.x
        api.prompt_window.y = event.y

    def do_move(event):
        x = event.x_root - api.prompt_window.x
        y = event.y_root - api.prompt_window.y
        api.prompt_window.geometry(f"+{x}+{y}")

    # Bind the scheduling function to key releases
    api.editor.text_area.bind("<KeyRelease>", schedule_suggestion)
    # Bind Tab to confirm the suggestion
    api.editor.text_area.bind("<Tab>", confirm_suggestion)
    # Bind other keys to cancel the suggestion
    api.editor.text_area.bind("<Key>", cancel_suggestion)
    # Bind Ctrl+i to open the prompt menu
    api.editor.text_area.bind("<Control-i>", open_prompt_menu)
